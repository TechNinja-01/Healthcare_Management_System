"""add hospital fields

Revision ID: f1729917e67a
Revises: 995eed8cc539
Create Date: 2026-08-19 10:37:58.584653

Safe follow-up for hospital fields. Does not drop user_permissions.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "f1729917e67a"
down_revision: Union[str, Sequence[str], None] = "995eed8cc539"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        """
        UPDATE doctors
        SET hospital_name = COALESCE(NULLIF(TRIM(hospital_name), ''), 'Unknown Hospital')
        WHERE hospital_name IS NULL OR TRIM(hospital_name) = ''
        """
    )
    op.execute(
        """
        UPDATE doctors
        SET address = COALESCE(NULLIF(TRIM(address), ''), 'Address not set')
        WHERE address IS NULL OR TRIM(address) = ''
        """
    )
    op.alter_column(
        "doctors",
        "hospital_name",
        existing_type=sa.VARCHAR(length=100),
        nullable=False,
    )
    op.alter_column(
        "doctors",
        "address",
        existing_type=sa.VARCHAR(length=100),
        nullable=False,
    )


def downgrade() -> None:
    op.alter_column(
        "doctors",
        "address",
        existing_type=sa.VARCHAR(length=100),
        nullable=True,
    )
    op.alter_column(
        "doctors",
        "hospital_name",
        existing_type=sa.VARCHAR(length=100),
        nullable=True,
    )
